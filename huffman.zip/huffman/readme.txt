Practica realitzada per Juan Marin Vega y Fernando Moral Algaba.

Consta del script main.py que es el principal y huffman.py que es la llibreria on hem programat el codificador.
Nomes cal executar
>> python  main.py
I es veurán totes les pases dels exercicis implementats
